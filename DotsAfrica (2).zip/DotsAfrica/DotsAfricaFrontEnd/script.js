// Simulate a simple in-memory "database"
let users = [];
let currentUser = null;
let tasks = [];

// Event listeners for login, registration, and task management
document.getElementById('login-form').addEventListener('submit', handleLogin);
document.getElementById('register-form').addEventListener('submit', handleRegister);
document.getElementById('show-register').addEventListener('click', showRegisterForm);
document.getElementById('show-login').addEventListener('click', showLoginForm);
document.getElementById('logout-btn').addEventListener('click', logout);
document.getElementById('create-task-btn').addEventListener('click', showTaskForm);
document.getElementById('cancel-task-btn').addEventListener('click', hideTaskForm);
document.getElementById('save-task-btn').addEventListener('click', saveTask);

// Show Register Form
function showRegisterForm(event) {
    event.preventDefault();
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('register-form').style.display = 'block';
}

// Show Login Form
function showLoginForm(event) {
    event.preventDefault();
    document.getElementById('register-form').style.display = 'none';
    document.getElementById('login-form').style.display = 'block';
}

// Handle User Login
function handleLogin(event) {
    event.preventDefault();
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    currentUser = users.find(user => user.username === username && user.password === password);
    
    if (currentUser) {
        document.getElementById('auth-section').style.display = 'none';
        document.getElementById('task-section').style.display = 'block';
        loadTasks();
    } else {
        alert('Invalid credentials');
    }
}

// Handle User Registration
function handleRegister(event) {
    event.preventDefault();
    const username = document.getElementById('register-username').value;
    const email = document.getElementById('register-email').value;
    const fullname = document.getElementById('register-fullname').value;
    const password = document.getElementById('register-password').value;
    const confirmPassword = document.getElementById('register-confirm-password').value;
    
    if (password !== confirmPassword) {
        alert('Passwords do not match!');
        return;
    }

    if (users.find(user => user.username === username)) {
        alert('Username already taken');
    } else {
        users.push({ username, email, fullname, password });
        alert('Registration successful! Please log in.');
        showLoginForm(event);
    }
}

// Logout User
function logout() {
    currentUser = null;
    document.getElementById('task-section').style.display = 'none';
    document.getElementById('auth-section').style.display = 'block';
}

// Show Task Creation Form
function showTaskForm() {
    document.getElementById('task-form').style.display = 'block';
}

// Hide Task Creation Form
function hideTaskForm() {
    document.getElementById('task-form').style.display = 'none';
}

// Save New Task
function saveTask() {
    const title = document.getElementById('task-title').value;
    const description = document.getElementById('task-description').value;
    const dueDate = document.getElementById('task-due-date').value;

    const newTask = {
        id: tasks.length + 1,
        title,
        description,
        dueDate,
        isComplete: false,
        user: currentUser.username
    };
    
    tasks.push(newTask);
    loadTasks();
    hideTaskForm();
}

// Load Tasks for Current User
function loadTasks() {
    const taskList = document.getElementById('task-list');
    taskList.innerHTML = '';

    tasks
        .filter(task => task.user === currentUser.username)
        .forEach(task => {
            const taskDiv = document.createElement('div');
            taskDiv.innerHTML = `
                <h4>${task.title}</h4>
                <p>${task.description}</p>
                <p>Due: ${task.dueDate}</p>
                <p>Status: ${task.isComplete ? 'Completed' : 'Pending'}</p>
                <button onclick="deleteTask(${task.id})">Delete</button>
                <button onclick="markTaskComplete(${task.id})">Mark as Complete</button>
            `;
            taskList.appendChild(taskDiv);
        });
}

// Delete Task
function deleteTask(taskId) {
    tasks = tasks.filter(task => task.id !== taskId);
    loadTasks();
}

// Mark Task as Complete
function markTaskComplete(taskId) {
    const task = tasks.find(task => task.id === taskId);
    if (task) {
        task.isComplete = true;
        loadTasks();
    }
}
