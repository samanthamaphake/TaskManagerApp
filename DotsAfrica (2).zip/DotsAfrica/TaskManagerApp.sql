create database dotAfricaPractice
go

CREATE TABLE Users (
    UserId INT PRIMARY KEY,
    Username VARCHAR(50) UNIQUE NOT NULL,
    PasswordUser VARCHAR(255) NOT NULL
);

CREATE TABLE Tasks (
    TaskId INT PRIMARY KEY,
    UserId INT NOT NULL,
    Title VARCHAR(100) NOT NULL,
    Description TEXT,
    DueDate DATE NOT NULL,
    IsComplete BIT NOT NULL,
    FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
);

CREATE TABLE TaskEvents (
    EventId INT IDENTITY(1,1) PRIMARY KEY,
    TaskId INT NOT NULL,
    EventType NVARCHAR(50) NOT NULL CHECK (EventType IN ('Created', 'Marked Complete', 'Deleted')),
    EventTimestamp DATETIME DEFAULT GETDATE(),
    EventDescription NVARCHAR(MAX),
    FOREIGN KEY (TaskId) REFERENCES Tasks(TaskId) ON DELETE CASCADE
);

