﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotsAfricaTaskManager
{
    enum Menu
    {
        Register = 1,
        Login,
        Create_Task,
        View_Tasks,
        Delete_Task,
        Mark_Task,
        Logout,
        Exit
    }

    internal class Program
    {
        static void Main(string[] args)
        {
            var taskManager = new TaskManagerParent();

            // Subscribe to task events
            taskManager.TaskCreated += OnTaskCreated;
            taskManager.TaskMarked += OnTaskMarked;
            taskManager.TaskDeleted += OnTaskDeleted;

            while (true)
            {
                Console.WriteLine("\n======================================");
                foreach (Menu item in Enum.GetValues(typeof(Menu)))
                {
                    Console.WriteLine($"Press {(int)item} for {item.ToString().Replace("_", " ")}");
                }
                Console.WriteLine("======================================");

                Console.Write("Please enter your choice: ");
                if (int.TryParse(Console.ReadLine(), out int menuChoice))
                {
                    switch ((Menu)menuChoice)
                    {
                        case Menu.Register:
                            Console.Write("Enter username: ");
                            string username = Console.ReadLine();
                            Console.Write("Enter password: ");
                            string password = ReadPassword();
                            UserManagement.Register(username, password);
                            break;

                        case Menu.Login:
                            Console.Write("Enter username: ");
                            username = Console.ReadLine();
                            Console.Write("Enter password: ");
                            password = ReadPassword();
                            if (UserManagement.Login(username, password))
                                Console.WriteLine("Login successful!");
                            break;

                        case Menu.Create_Task:
                            taskManager.Create();
                            break;

                        case Menu.View_Tasks:
                            taskManager.View();
                            break;

                        case Menu.Delete_Task:
                            taskManager.Delete();
                            break;

                        case Menu.Mark_Task:
                            taskManager.Mark();
                            break;

                        case Menu.Logout:
                            UserManagement.Logout();
                            break;

                        case Menu.Exit:
                            Console.WriteLine("Goodbye!");
                            Environment.Exit(0);
                            break;

                        default:
                            Console.WriteLine("Invalid option! Please try again.");
                            break;
                    }
                }
            }
        }
        static string ReadPassword()
        {
            var password = new System.Text.StringBuilder();
            ConsoleKeyInfo keyInfo;
            do
            {
                keyInfo = Console.ReadKey(true);
                if (keyInfo.Key != ConsoleKey.Enter)
                {
                    password.Append(keyInfo.KeyChar);
                    Console.Write("*");  // Mask the password with asterisks
                }
            } while (keyInfo.Key != ConsoleKey.Enter);
            Console.WriteLine();
            return password.ToString();
        }

        static void ExitApplication()
        {
            Console.WriteLine("Are you sure you want to exit? (y/n)");
            char exitChoice = Console.ReadLine().ToLower()[0];
            if (exitChoice == 'y')
            {
                Console.WriteLine("Goodbye!");
                Environment.Exit(0);
            }
            else
            {
                Console.WriteLine("Returning to the menu...");
            }
        }

        // Event handlers
        static void OnTaskCreated(object sender, TaskEventArgs e)
        {
            Console.WriteLine($"Event: {e.TaskInfo1}");
        }

        static void OnTaskMarked(object sender, TaskEventArgs e)
        {
            Console.WriteLine($"Event: {e.TaskInfo1}");
        }

        static void OnTaskDeleted(object sender, TaskEventArgs e)
        {
            Console.WriteLine($"Event: {e.TaskInfo1}");
        }
    }
}
