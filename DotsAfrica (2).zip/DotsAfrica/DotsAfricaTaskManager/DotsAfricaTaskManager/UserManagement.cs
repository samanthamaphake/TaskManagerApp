﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotsAfricaTaskManager
{
    internal class UserManagement
    {
        //creating the fields
        string username, password;

        //creating a default constructor
        public UserManagement()
        {

        }

        //creating parameterized constructor
        public UserManagement(string username, string password)
        {
            this.username = username;
            this.password = password;
        }

        //creating properties
        public string Username { get => username; set => username = value; }
        public string Password { get => password; set => password = value; }

        private static readonly Dictionary<string, string> Users = new Dictionary<string, string>(); // Store registered users
        private static string currentUser = null; // Keep track of the logged-in user

        public static void Register(string username, string password)
        {
            if (Users.ContainsKey(username))
            {
                Console.WriteLine("Username already exists. Please choose another.");
            }
            else
            {
                Users[username] = password;
                Console.WriteLine("Registration successful!");
            }
        }

        public static bool Login(string username, string password)
        {
            if (Users.TryGetValue(username, out string storedPassword) && storedPassword == password)
            {
                currentUser = username;
                return true;
            }
            Console.WriteLine("Invalid username or password.");
            return false;
        }

        public static void Logout()
        {
            currentUser = null;
            Console.WriteLine("You have been logged out.");
        }

        public static string GetCurrentUser() => currentUser;
    }
}
