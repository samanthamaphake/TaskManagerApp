﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotsAfricaTaskManager
{
    internal class TaskManagerParent:TaskManagement, ITaskManager

    {
        public TaskManagerParent() : base()
        {

        }

        public TaskManagerParent(int id, string title, string description, DateTime dueDate, bool isComplete) : base(id, title, description, dueDate, isComplete)
        {

        }

        private static readonly Dictionary<string, List<TaskManagement>> UserTasks = new Dictionary<string, List<TaskManagement>>(); // Tasks per user
        private int nextID = 1;

        public event EventHandler<TaskEventArgs> TaskCreated;
        public event EventHandler<TaskEventArgs> TaskMarked;
        public event EventHandler<TaskEventArgs> TaskDeleted;

        private List<TaskManagement> GetCurrentUserTasks()
        {
            string currentUser = UserManagement.GetCurrentUser();
            if (currentUser == null) return null;

            if (!UserTasks.ContainsKey(currentUser))
                UserTasks[currentUser] = new List<TaskManagement>();

            return UserTasks[currentUser];
        }

        public void Create()
        {
            var tasks = GetCurrentUserTasks();
            if (tasks == null)
            {
                Console.WriteLine("No user is logged in.");
                return;
            }

            var task = new TaskManagement
            {
                Id = nextID++
            };

            Console.Write("Enter Task Title: ");
            task.Title = Console.ReadLine();

            Console.Write("Enter Task Description: ");
            task.Description = Console.ReadLine();

            Console.Write("Enter Due Date (yyyy-MM-dd): ");
            if (DateTime.TryParse(Console.ReadLine(), out DateTime dueDate) && dueDate >= DateTime.Now)
            {
                task.DueDate = dueDate;
                tasks.Add(task);

                TaskCreated?.Invoke(this, new TaskEventArgs($"Task '{task.Title}' created."));
            }
            else
            {
                Console.WriteLine("Invalid date. Task not created.");
            }
        }

        public void View()
        {
            var tasks = GetCurrentUserTasks();
            if (tasks == null || tasks.Count == 0)
            {
                Console.WriteLine("No tasks available.");
                return;
            }

            foreach (var task in tasks)
            {
                Console.WriteLine(task);
            }
        }

        public void Delete()
        {
            var tasks = GetCurrentUserTasks();
            if (tasks == null || tasks.Count == 0)
            {
                Console.WriteLine("No tasks to delete.");
                return;
            }

            Console.Write("Enter Task ID to delete: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var task = tasks.Find(t => t.Id == id);
                if (task != null)
                {
                    tasks.Remove(task);
                    TaskDeleted?.Invoke(this, new TaskEventArgs($"Task '{task.Title}' deleted."));
                }
                else
                {
                    Console.WriteLine("Task not found.");
                }
            }
        }

        public void Mark()
        {
            var tasks = GetCurrentUserTasks();
            if (tasks == null || tasks.Count == 0)
            {
                Console.WriteLine("No tasks to mark.");
                return;
            }

            Console.Write("Enter Task ID to mark as complete: ");
            if (int.TryParse(Console.ReadLine(), out int id))
            {
                var task = tasks.Find(t => t.Id == id);
                if (task != null)
                {
                    task.IsComplete = true;
                    TaskMarked?.Invoke(this, new TaskEventArgs($"Task '{task.Title}' marked as complete."));
                }
                else
                {
                    Console.WriteLine("Task not found.");
                }
            }
        }
    }
}