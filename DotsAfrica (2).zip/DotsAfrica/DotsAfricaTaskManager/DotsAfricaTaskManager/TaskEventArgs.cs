﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotsAfricaTaskManager
{
    internal class TaskEventArgs : EventArgs
    {
        //creating the fields
        string TaskInfo;

        //creating the default constructor
        public TaskEventArgs()
        {

        }
        //creating parameterized constructor
        public TaskEventArgs(string taskInfo)
        {
            TaskInfo = taskInfo;
        }

        //creating properties
        public string TaskInfo1 { get => TaskInfo; set => TaskInfo = value; }
    }
}
