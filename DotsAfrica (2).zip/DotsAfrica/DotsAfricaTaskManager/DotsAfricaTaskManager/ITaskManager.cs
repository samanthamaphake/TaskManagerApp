﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotsAfricaTaskManager
{
    internal interface ITaskManager
    {
        void Create();
        void Mark();
        void Delete();
        void View();
    }
}
