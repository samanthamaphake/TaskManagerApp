﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DotsAfricaTaskManager
{
    internal class TaskManagement
    {
        //creating the fields
        int id;
        string title, description;
        DateTime dueDate;
        bool isComplete;

        //creating default constructor
        public TaskManagement()
        {

        }

        //creating parameterized constructor
        public TaskManagement(int id, string title, string description, DateTime dueDate, bool isComplete)
        {
            this.id = id;
            this.title = title;
            this.description = description;
            this.dueDate = dueDate;
            this.isComplete = isComplete;
        }

        //creating properties
        public int Id { get => id; set => id = value; }
        public string Title { get => title; set => title = value; }
        public string Description { get => description; set => description = value; }
        public DateTime DueDate { get => dueDate; set => dueDate = value; }
        public bool IsComplete { get => isComplete; set => isComplete = value; }

        //creating a string that will display on the screen
        public override string ToString()
        {
            return $"ID: {id}, Title: {title}, due: {dueDate.ToShortDateString()}, Completed: {isComplete}";

        }
    }
}
